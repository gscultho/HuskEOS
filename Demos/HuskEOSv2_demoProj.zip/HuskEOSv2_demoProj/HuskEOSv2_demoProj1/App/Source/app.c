/* This demo shows use of the mailbox, flags, and mutex modules. The tasks appTask_blinkBlueLED and appTask_blinkRedLED 
   blink the LEDs on/off at set frequencies. The task appTask_buttonDetectPress performs button debouncing on SW4 of the Tiva 
   launchpad. When it registers a positive press, it sets two event flags to notify appTask_blinkBlueLED and appTask_blinkRedLED 
   to change their LED blink frequencies. The two LED tasks reset the flags, and then send their new blink frequencies via two
   mailboxes to appTask_transmitBlinkRates. Task appTask_transmitBlinkRates then sends this information to a serial terminal
   via UART. appTask_transmitPulse transmits a periodic heartbeat at a higher priority than appTask_transmitBlinkRates to demonstrate
   the Mutex module. */

/* OS includes */
#include "rtos_cfg.h"
#include "sch.h"
#include "mutex.h"
#include "mailbox.h"
#include "flags.h"

/* Other includes. */
#include <stdint.h>
#include <stdbool.h>
#include "sysctl.h"
#include "gpio.h"
#include "hw_memmap.h"
#include "hw_gpio.h"
#include "hw_types.h"
#include "pin_map.h"
#include "uartstdio.h"
#include "uart.h"


/*************************************************************************/
/*  Definitions                                                          */
/*************************************************************************/
#define APP_TICK_MS            (1)
#define APP_TASK_STACK_SIZE    (200)

#define APP_TASK1_PRIO         (0)
#define APP_TASK2_PRIO         (1)
#define APP_TASK3_PRIO         (2)
#define APP_TASK4_PRIO         (3)
#define APP_TASK5_PRIO         (4)

#define APP_TASK1_PERIOD       (5)
#define APP_TASK4_PERIOD       (1000)
#define APP_TASK5_PERIOD       (5)

#define APP_REDLED_FLAG_MASK   (0x01)
#define APP_BLUELED_FLAG_MASK  (0x02)
#define APP_BLUELED_MBOX_NUM   (0)
#define APP_REDLED_MBOX_NUM    (1)

/*************************************************************************/
/*  Private Function Prototypes                                          */
/*************************************************************************/
static void app_portFInit(void);
static void app_UARTInit(void);
static void app_init(void);

/* Application threads. */
static void appTask_buttonDetectPress(void);
static void appTask_blinkBlueLED(void);
static void appTask_blinkRedLED(void);
static void appTask_transmitPulse(void);
static void appTask_transmitBlinkRates(void);

/*************************************************************************/
/*  Global Variables                                                     */
/*************************************************************************/
static U4 u4_s_blinkRatesMs[10];

/* Task stacks. */
static OS_STACK u4_taskStack [APP_TASK_STACK_SIZE];
static OS_STACK u4_taskStack2[APP_TASK_STACK_SIZE];
static OS_STACK u4_taskStack3[APP_TASK_STACK_SIZE];
static OS_STACK u4_taskStack4[APP_TASK_STACK_SIZE];
static OS_STACK u4_taskStack5[APP_TASK_STACK_SIZE];

/* OS resources used. */
static OSMutex*    app_s_UARTMutex;
static OSFlagsObj* app_sp_LEDFlags;

/*************************************************************************/

/*************************************************************************/
/*  Function Name: main                                                  */
/*  Purpose:       Control should be handed to RTOS.                     */
/*                 at end of function.                                   */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
int main()
{
  /* Initialize OS with tick period. */
  vd_OS_init(APP_TICK_MS);
  
  /* Initialize application. */
  app_init();
  
  /* Init task 1. */
  u1_OSsch_createTask(&appTask_buttonDetectPress,             /* Pointer to function definition. */
                     &u4_taskStack[APP_TASK_STACK_SIZE - 1],  /* Pointer to highest memory address in stack. */
                     sizeof(u4_taskStack)/sizeof(OS_STACK),   /* Size of stack in terms of OS_STACK. */
                     APP_TASK1_PRIO,                          /* Priority of task. */
                     APP_TASK1_PRIO);                         /* ID number of task for some API calls. Kept same as priority for simplicity. */
  /* Init task 2. */
  u1_OSsch_createTask(&appTask_blinkBlueLED,                  /* Pointer to function definition. */
                     &u4_taskStack2[APP_TASK_STACK_SIZE - 1], /* Pointer to highest memory address in stack. */
                     sizeof(u4_taskStack2)/sizeof(OS_STACK),  /* Size of stack in terms of OS_STACK. */
                     APP_TASK2_PRIO,                          /* Priority of task. */
                     APP_TASK2_PRIO);                         /* ID number of task for some API calls. Kept same as priority for simplicity. */
  /* Init task 3. */
  u1_OSsch_createTask(&appTask_blinkRedLED,                   /* Pointer to function definition. */
                     &u4_taskStack3[APP_TASK_STACK_SIZE - 1], /* Pointer to highest memory address in stack. */
                     sizeof(u4_taskStack3)/sizeof(OS_STACK),  /* Size of stack in terms of OS_STACK. */
                     APP_TASK3_PRIO,                          /* Priority of task. */
                     APP_TASK3_PRIO);                         /* ID number of task for some API calls. Kept same as priority for simplicity. */
                     
  /* Init task 4. */
  u1_OSsch_createTask(&appTask_transmitPulse,                 /* Pointer to function definition. */
                     &u4_taskStack4[APP_TASK_STACK_SIZE - 1], /* Pointer to highest memory address in stack. */
                     sizeof(u4_taskStack4)/sizeof(OS_STACK),  /* Size of stack in terms of OS_STACK. */
                     APP_TASK4_PRIO,                          /* Priority of task. */
                     APP_TASK4_PRIO);                         /* ID number of task for some API calls. Kept same as priority for simplicity. */
                     
  /* Init task 5. */
  u1_OSsch_createTask(&appTask_transmitBlinkRates,            /* Pointer to function definition. */
                     &u4_taskStack5[APP_TASK_STACK_SIZE - 1], /* Pointer to highest memory address in stack. */
                     sizeof(u4_taskStack5)/sizeof(OS_STACK),  /* Size of stack in terms of OS_STACK. */
                     APP_TASK5_PRIO,                          /* Priority of task. */
                     APP_TASK5_PRIO);                         /* ID number of task for some API calls. Kept same as priority for simplicity. */
                     
  /* Hand control to OS, will not return. */                   
  vd_OSsch_start();
}
  
/*************************************************************************/
/*  Function Name: app_init                                              */
/*  Purpose:       Initialize application.                               */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void app_init(void)
{
  u4_s_blinkRatesMs[0] = 1000;
  u4_s_blinkRatesMs[1] = 1200;
  u4_s_blinkRatesMs[2] = 500;
  u4_s_blinkRatesMs[3] = 900;
  u4_s_blinkRatesMs[4] = 200;
  u4_s_blinkRatesMs[5] = 900;
  u4_s_blinkRatesMs[6] = 300;
  u4_s_blinkRatesMs[7] = 200;
  u4_s_blinkRatesMs[8] = 800;
  u4_s_blinkRatesMs[9] = 200;
  
  app_portFInit();
  app_UARTInit();
  (void)u1_OSflags_init(&app_sp_LEDFlags, 0x00);
  (void)u1_OSmutex_init(&app_s_UARTMutex, MUTEX_AVAILABLE);
}

/*************************************************************************/
/*  Function Name: app_UARTInit                                          */
/*  Purpose:       Initialize UART                                       */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void app_UARTInit(void)
{
  SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
  GPIOPinConfigure(GPIO_PA0_U0RX);
  GPIOPinConfigure(GPIO_PA1_U0TX);
  GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
  UARTStdioConfig(0, 115200, SysCtlClockGet()); 
}

/*************************************************************************/
/*  Function Name: app_portFInit                                         */
/*  Purpose:       Initialize buttons and LEDs.                          */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void app_portFInit(void)
{
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);  //Enable clock on GPIO PORTF
  
  while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF))
  {
    //NOP
  }
  
  GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3);  //Sets pins 1,2,3 as outputs
  
  //Configure PORTF switches
  HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;  //unlock PF0
  HWREG(GPIO_PORTF_BASE + GPIO_O_CR) |= 0x01;
  HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = 0;
  GPIODirModeSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_DIR_MODE_IN);
  GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
}

/*************************************************************************/
/*  Function Name: appTask_buttonDetectPress                             */
/*  Purpose:       Manages pressed/released state of SW4 and sets flags  */
/*                 if pressed. Debounces SW4 button to properly detect   */
/*                 press/release. Debounce time is defined as 25ms in    */
/*                 this case for both press and release.                 */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void appTask_buttonDetectPress(void)
{
  U4 u4_t_sleepTime;
  U1 u1_t_buttonDebounceHICount;
  U1 u1_t_buttonDebounceLOCount;
  U1 u1_t_sw4Read;
  U1 u1_t_sw4Sts; /* 1 = pressed, 0 = released. */

  u4_t_sleepTime             = APP_TASK1_PERIOD;
  u1_t_buttonDebounceHICount = 0;
  u1_t_buttonDebounceLOCount = 0;
  u1_t_sw4Sts                = 0;
  
  while(1)
  {
    /* Get signal on button pin. */
    u1_t_sw4Read = !(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4));
    
    /* If switch reads HIGH. */
    if(u1_t_sw4Read)
    {
      /* Reset LOW counter. */
      u1_t_buttonDebounceLOCount = 0;
      
      /* Check if HIGH for 25ms and increment counter for next check if not. */
      if(u1_t_buttonDebounceHICount == 5)
      {
        /* Reset HIGH counter. */
        u1_t_buttonDebounceHICount = 0;
        
        /* If switch state is currently "released", set state to "pressed" and set flags to change blink period of both LEDs. */
        if(u1_t_sw4Sts == 0)
        {
          u1_t_sw4Sts = 1;
          (void)u1_OSflags_postFlags(app_sp_LEDFlags, (U1)(APP_REDLED_FLAG_MASK|APP_BLUELED_FLAG_MASK), (U1)FLAGS_WRITE_SET);
        }
      } 
      else
      {
        u1_t_buttonDebounceHICount++;
      }
    }
    else
    {
      /* Reset HIGH counter. */
      u1_t_buttonDebounceHICount = 0;
      
      /* Check if LOW for 25ms and increment counter for next check. */
      if(u1_t_buttonDebounceLOCount == 5)
      {
        /* Reset LOW counter. */
        u1_t_buttonDebounceLOCount = 0;
        /* Set switch state to "released". */
        u1_t_sw4Sts = 0;
      }
      else
      {
        u1_t_buttonDebounceLOCount++;
      }
    }
    
    vd_OSsch_taskSleep(u4_t_sleepTime);
  }     
}

/*************************************************************************/
/*  Function Name: appTask_blinkBlueLED                                  */
/*  Purpose:                                                             */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void appTask_blinkBlueLED(void)
{
  U1 u1_t_blinkPeriod;
  U1 u1_t_blueLEDRead;
  U1 u1_t_sendMailError;
  
  u1_t_blinkPeriod = 0;

  while(1)
  {
    /* Check if blue LED flag is set. */
    if(u1_OSflags_checkFlags(app_sp_LEDFlags) & APP_BLUELED_FLAG_MASK)
    {
      /* Take a new "random" blink period if so. */
      u1_t_blinkPeriod = (u1_t_blinkPeriod + 1)%10;
      /* Clear flag. */
      u1_OSflags_postFlags(app_sp_LEDFlags, (U1)(APP_BLUELED_FLAG_MASK), (U1)FLAGS_WRITE_CLEAR);
      
      /* Send new blink period via mailbox. If mailbox is full from last send, then clear the stale data and try again. */
      if(u1_OSmbox_sendMail((U1)APP_BLUELED_MBOX_NUM, 0, u4_s_blinkRatesMs[u1_t_blinkPeriod], &u1_t_sendMailError) != MBOX_SUCCESS)
      {
        vd_OSmbox_clearMailbox((U1)APP_BLUELED_MBOX_NUM);
        (void)u1_OSmbox_sendMail((U1)APP_BLUELED_MBOX_NUM, 0, u4_s_blinkRatesMs[u1_t_blinkPeriod], &u1_t_sendMailError);
      }
    }
    
    /* Toggle LED. */
    u1_t_blueLEDRead = GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_2);
    u1_t_blueLEDRead ^= (U1)GPIO_PIN_2;
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, u1_t_blueLEDRead); 
    
    /* Go to sleep for whatever the current period is. */
    vd_OSsch_taskSleep(u4_s_blinkRatesMs[u1_t_blinkPeriod]);
  }     
}

/*************************************************************************/
/*  Function Name: appTask_blinkRedLED                                   */
/*  Purpose:                                                             */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void appTask_blinkRedLED(void)
{
  U1 u1_t_blinkPeriod;
  U1 u1_t_redLEDRead;
  U1 u1_t_sendMailError;
  
  u1_t_blinkPeriod = 5;

  while(1)
  {
    /* Check if red LED flag is set. */
    if(u1_OSflags_checkFlags(app_sp_LEDFlags) & APP_REDLED_FLAG_MASK)
    {
      /* Take a new "random" blink period if so. */
      u1_t_blinkPeriod = (u1_t_blinkPeriod + 1)%10;
      /* Clear flag. */
      u1_OSflags_postFlags(app_sp_LEDFlags, (U1)(APP_REDLED_FLAG_MASK), (U1)FLAGS_WRITE_CLEAR);
      
      /* Send new blink period via mailbox. If mailbox is full from last send, then clear the stale data and try again. */
      if(u1_OSmbox_sendMail((U1)APP_REDLED_MBOX_NUM, 0, u4_s_blinkRatesMs[u1_t_blinkPeriod], &u1_t_sendMailError) != MBOX_SUCCESS)
      {
        vd_OSmbox_clearMailbox((U1)APP_REDLED_MBOX_NUM);
        (void)u1_OSmbox_sendMail((U1)APP_REDLED_MBOX_NUM, 0, u4_s_blinkRatesMs[u1_t_blinkPeriod], &u1_t_sendMailError);
      }
    }
    
    /* Toggle LED. */
    u1_t_redLEDRead = GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_1);
    u1_t_redLEDRead ^= (U1)GPIO_PIN_1;
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, u1_t_redLEDRead); 
    
    /* Go to sleep for whatever the current period is. */
    vd_OSsch_taskSleep(u4_s_blinkRatesMs[u1_t_blinkPeriod]);
  }    
}

/*************************************************************************/
/*  Function Name: appTask_transmitPulse                                 */
/*  Purpose:                                                             */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void appTask_transmitPulse(void)
{
  U4 u4_t_sleepTime;
  U1 u1_t_mutexRtnSts;
  
  u4_t_sleepTime = APP_TASK4_PERIOD;

  while(1)
  {
    u1_t_mutexRtnSts = u1_OSmutex_lock(app_s_UARTMutex, 1000);
      
    if(u1_t_mutexRtnSts == MUTEX_SUCCESS)
    {
      UARTprintf("pulse\n");
      (void)u1_OSmutex_unlock(app_s_UARTMutex);
      vd_OSsch_taskSleep(u4_t_sleepTime);
    }
  }    
  
}

/*************************************************************************/
/*  Function Name: appTask_transmitBlinkRates                            */
/*  Purpose:                                                             */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void appTask_transmitBlinkRates(void)
{
  U4 u4_t_sleepTime;
  U1 u1_t_error;
  U4 u4_t_blinkRateTx;
  
  u4_t_sleepTime = APP_TASK5_PERIOD;

  while(1)
  {
    if(mail_OSmbox_checkMail(APP_BLUELED_MBOX_NUM, &u1_t_error))
    {
      u4_t_blinkRateTx = mail_OSmbox_getMail(APP_BLUELED_MBOX_NUM, 0, &u1_t_error);
      
      (void)u1_OSmutex_lock(app_s_UARTMutex, 5);
      UARTprintf("Blue LED period = %d ms\n", u4_t_blinkRateTx);
      u1_OSmutex_unlock(app_s_UARTMutex);
    }
    else{}
      
    if(mail_OSmbox_checkMail(APP_REDLED_MBOX_NUM, &u1_t_error))
    {
      u4_t_blinkRateTx = mail_OSmbox_getMail(APP_REDLED_MBOX_NUM, 0, &u1_t_error);
      
      (void)u1_OSmutex_lock(app_s_UARTMutex, 5);
      UARTprintf("Red LED period = %d ms\n", u4_t_blinkRateTx);
      u1_OSmutex_unlock(app_s_UARTMutex);
    }
    else{}
    
    vd_OSsch_taskSleep(u4_t_sleepTime);
  }    
  
}
