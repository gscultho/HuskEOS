/*************************************************************************/
/*  File Name:                                                           */
/*  Purpose:                                                             */
/*************************************************************************/

/*************************************************************************/
/*  Includes                                                             */
/*************************************************************************/
#define PART_TM4C123GH6PM                  (1)


#include <stdint.h>
#include <stdbool.h>
#include "sysctl.h"
#include "gpio.h"
#include "hw_memmap.h"
#include "hw_gpio.h"
#include "hw_types.h"
#include "pin_map.h"
#include "uart.h"
#include "uartstdio.h"
#include "sch.h"
#include "mailbox.h"
#include "queue.h"
#include "sysctl.h"
#include "flags.h"
#include "timeHandler.h"


/*************************************************************************/
/*  External References                                                  */
/*************************************************************************/


/*************************************************************************/
/*  Definitions                                                          */
/*************************************************************************/
#define APP_BLINKY1_MAIL_INDEX       (0)
#define APP_BLINKY2_MAIL_INDEX       (1)
#define APP_BLINKY1_FLAG_MASK        (0x01)
#define APP_BLINKY2_FLAG_MASK        (0x02)
#define APP_TASK_ID_TASK_ONE         (1)
#define APP_TASK_ID_TASK_TWO         (2)
#define APP_TASK_ID_TASK_THREE       (3)
#define APP_QUEUE_ID_TASK_INFO       (0)
#define APP_QUEUE_DATA_TASK_START    (0x80)
#define APP_QUEUE_DATA_TASK_END      (0x00)
#define APP_QUEUE_MSG_NUM_MS_MASK    (0xFFFF0000)
#define APP_QUEUE_MSG_TASK_ID_MASK   (0x0000000F)
#define APP_MASK_U4_TO_U2            (0x0000FFFF)


/*************************************************************************/
/*  Private Function Prototypes                                          */
/*************************************************************************/
static void blinkGrn(void);
static void blinkBlue(void);
static void blinkRed(void);
static void sendSchTable(void);


/*************************************************************************/
/*  Global Variables                                                     */
/*************************************************************************/
static U4 u4_taskStack [RTOS_CONFIG_TASK_STACK_SIZE];
static U4 u4_taskStack2[RTOS_CONFIG_TASK_STACK_SIZE];
static U4 u4_taskStack3[RTOS_CONFIG_TASK_STACK_SIZE];
static U4 u4_taskStack4[RTOS_CONFIG_TASK_STACK_SIZE];


/*************************************************************************/

/*************************************************************************/
/*  Function Name: main                                                  */
/*  Purpose:       startup.s jumps here. Control should be handed to RTOS*/
/*                 at end of function.                                   */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
int main(void)
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
  GPIOPinConfigure(GPIO_PA0_U0RX);
  GPIOPinConfigure(GPIO_PA1_U0TX);
  GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	UARTStdioConfig(0, 115200, SysCtlClockGet()); 
	
	vd_sch_init();
	vd_mbox_init();
	vd_queue_init();
	
	//Enable PORTF
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);  //Enable clock on GPIO PORTF
	
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF))
	{
		//NOP
	}
	
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3);  //Sets pins 1,2,3 as outputs
	
	//Configure PORTF switches
	HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;  //unlock PF0
	HWREG(GPIO_PORTF_BASE + GPIO_O_CR) |= 0x01;
	HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = 0;
	GPIODirModeSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_DIR_MODE_IN);
	GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);

	u1_sch_createTask(&blinkGrn,     &u4_taskStack [RTOS_CONFIG_TASK_STACK_SIZE - 1]);
  u1_sch_createTask(&blinkBlue,    &u4_taskStack2[RTOS_CONFIG_TASK_STACK_SIZE - 1]);
	u1_sch_createTask(&blinkRed,     &u4_taskStack3[RTOS_CONFIG_TASK_STACK_SIZE - 1]);
	u1_sch_createTask(&sendSchTable, &u4_taskStack4[RTOS_CONFIG_TASK_STACK_SIZE - 1]);
  	
	vd_sch_start((U4)1);
}

/*************************************************************************/
/*  Function Name: blinkGrn                                              */
/*  Purpose:       Blink green LED and send scheduling ststs to queue.   */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void blinkGrn(void)
{
	U4 u4_t_index;
	U4 u4_t_message;
	
	while(1)
	{
		u4_t_message = 0;

		/* Form message for buffer to record task start time */
		u4_t_message |= ((APP_TASK_ID_TASK_ONE) | (APP_QUEUE_DATA_TASK_START) | ((u4_sch_getTicks())<< 16));
		
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3);
		
		/* Keep trying to send, sleep for 1ms between each attempt if blocked */
		while(!(u1_queue_put(APP_QUEUE_ID_TASK_INFO, 1, u4_t_message))){}
			
		for(u4_t_index = 0; u4_t_index < 20000; u4_t_index++){} //takes 5ms at 16MHz clock
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0);
			
		/* Form message for buffer to record task end time */	
		u4_t_message = 0;	
		u4_t_message |= ((APP_TASK_ID_TASK_ONE) | ((u4_sch_getTicks())<< 16));
			
		/* Keep trying to send, sleep for 1ms between each attempt if blocked */
		while(!(u1_queue_put(APP_QUEUE_ID_TASK_INFO, 1, u4_t_message))){}
			
		vd_sch_taskSleep(20);
	}
}

/*************************************************************************/
/*  Function Name: sendSchTable                                          */
/*  Purpose:       Pull data from FIFO and print over UART.              */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
//At 16MHz this takes 18ms to print data for two producer tasks
void sendSchTable(void)
{
	U1 u1_t_taskID;
	U4 u4_t_numMs;
	U1 u1_t_endOrStart;
	U4 u4_t_taskMsStart;
	U1 u1_t_bufferFlag;
	
  while(1)
	{
		u4_t_taskMsStart = u4_sch_getTicks() & APP_MASK_U4_TO_U2;
		u1_t_bufferFlag = 1;
		
		while(u1_t_bufferFlag)
		{
			u4_t_numMs = u4_queue_get(APP_QUEUE_ID_TASK_INFO, 0);
			
			if(u4_t_numMs != 0)
			{
			  u1_t_taskID     = u4_t_numMs & APP_QUEUE_MSG_TASK_ID_MASK;
			  u1_t_endOrStart = u4_t_numMs & APP_QUEUE_DATA_TASK_START;
			  u4_t_numMs     &= APP_QUEUE_MSG_NUM_MS_MASK;
			
			  if(u1_t_endOrStart == APP_QUEUE_DATA_TASK_START)
			  {
			    UARTprintf("Task %d began at %d ms\n", u1_t_taskID, u4_t_numMs>>16);
			  }
			  else
			  {
			  	UARTprintf("Task %d ended at %d ms\n", u1_t_taskID, u4_t_numMs>>16);
			  }
			}	
			else
			{
				u1_t_bufferFlag = 0;
			}
		}
		
		UARTprintf("Task 4 began at %d ms\n", u4_t_taskMsStart);
		UARTprintf("Task 4 ended at %d ms\n", u4_sch_getTicks() & APP_MASK_U4_TO_U2);
	}
}

/*************************************************************************/
/*  Function Name: blinkBlue                                             */
/*  Purpose:       Blink blue LED and send scheduling ststs to queue.    */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void blinkBlue(void)
{
	U4 u4_t_index;
	U4 u4_t_message;
	
	while(1)
	{
		u4_t_message = 0;
		
		/* Form message for buffer to record task start time */
		u4_t_message |= ((APP_TASK_ID_TASK_TWO) | (APP_QUEUE_DATA_TASK_START) | ((u4_sch_getTicks())<< 16));
			
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, GPIO_PIN_2);
		
		/* Keep trying to send, sleep for 1ms between each attempt if blocked */
		while(!(u1_queue_put(APP_QUEUE_ID_TASK_INFO, 1, u4_t_message))){}
			
		for(u4_t_index = 0; u4_t_index < 20000; u4_t_index++){} //takes 5ms at 16MHz clock
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 0);
			
		/* Form message for buffer to record task end time */	
		u4_t_message = 0;	
		u4_t_message |= ((APP_TASK_ID_TASK_TWO) | ((u4_sch_getTicks())<< 16));
			
		/* Keep trying to send, sleep for 1ms between each attempt if blocked */
		while(!(u1_queue_put(APP_QUEUE_ID_TASK_INFO, 1, u4_t_message))){}
			
		vd_sch_taskSleep(30);
	}
}

/*************************************************************************/
/*  Function Name: blinkRed                                              */
/*  Purpose:       Blink red LED and send scheduling ststs to queue.     */
/*  Arguments:     N/A                                                   */
/*  Return:        N/A                                                   */
/*************************************************************************/
static void blinkRed(void)
{
	U4 u4_t_index;
	U4 u4_t_message;
	
	while(1)
	{
		u4_t_message = 0;
		
		/* Form message for buffer to record task start time */
		u4_t_message |= ((APP_TASK_ID_TASK_THREE) | (APP_QUEUE_DATA_TASK_START) | ((u4_sch_getTicks())<< 16));
		
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, GPIO_PIN_1);
		
		/* Keep trying to send, sleep for 1ms between each attempt if blocked */
		while(!(u1_queue_put(APP_QUEUE_ID_TASK_INFO, 1, u4_t_message))){}
			
		for(u4_t_index = 0; u4_t_index < 20000; u4_t_index++){} //takes 5ms at 16MHz clock
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);
			
		/* Form message for buffer to record task end time */	
		u4_t_message = 0;	
		u4_t_message |= ((APP_TASK_ID_TASK_THREE) | ((u4_sch_getTicks())<< 16));
			
		/* Keep trying to send, sleep for 1ms between each attempt if blocked */
		while(!(u1_queue_put(APP_QUEUE_ID_TASK_INFO, 1, u4_t_message))){}
			
		vd_sch_taskSleep(10);
	}
}
